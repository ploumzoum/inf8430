Pour lancer le projet:

1 - Aller dans le dossier remise
2 - Faire rouler le NameService.jar
3 - Prendre en note l'adresse affich�e sur la console
4 - Ouvrir les serveurs de calcul (Calculator.jar) avec comme param�tres la malice, la capacit� et l'adresse du NameService
5 - Ouvrir le r�partiteur (Distributor.jar) avec comme param�tre l'adresse du NameService

Si un serveur de calcul est d�connect�, il faut red�marrer le NameService et tous les serveurs de calcul, puis le r�partiteur (l'ordre est n�cessaire).
