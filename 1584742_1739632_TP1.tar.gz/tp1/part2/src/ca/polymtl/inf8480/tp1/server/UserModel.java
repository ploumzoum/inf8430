package ca.polymtl.inf8480.tp1.server;

public class UserModel
{
    public String _userName;
    public String _password;

    public UserModel(String username, String password)
    {
        _userName = username;
        _password = password;
    }
}