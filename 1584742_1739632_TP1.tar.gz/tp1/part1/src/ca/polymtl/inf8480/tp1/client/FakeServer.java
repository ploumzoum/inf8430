<<<<<<< Updated upstream:tp1/ResponseTime_Analyzer/src/ca/polymtl/inf8480/tp1/client/FakeServer.java
package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	int execute(int a, int b) {
		return a + b;
	}
}
=======
package ca.polymtl.inf8480.tp1.client;

public class FakeServer {
	int execute(byte[] data, int size) {
		return size;
	}
}
>>>>>>> Stashed changes:tp1/part1/src/ca/polymtl/inf8480/tp1/client/FakeServer.java
